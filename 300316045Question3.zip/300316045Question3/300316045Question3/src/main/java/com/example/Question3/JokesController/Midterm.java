package com.example.Question3.JokesController;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Midterm {

    @RequestMapping("/")
    public String ListItems(){
        return "home";
    }

    /*@RequestMapping("/")
    public String myController(@ModelAttribute("joke") Model model) {
        model.addAtribute("joke", RandomJokes.getJoke());
        Return "index";
    }*/
}
