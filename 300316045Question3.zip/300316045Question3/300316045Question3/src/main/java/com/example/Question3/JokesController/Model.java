package com.example.Question3.JokesController;

public class Model {

}
